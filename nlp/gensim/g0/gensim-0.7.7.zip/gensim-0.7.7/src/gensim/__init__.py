"""
This package contains interfaces and functionality to compute pair-wise document 
similarities within a corpus of documents. 
"""

# for IPython tab-completion
import utils, matutils, interfaces, corpora, models, similarities

