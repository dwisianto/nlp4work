:mod:`summarization.pagerank_weighted` -- Weighted PageRank algorithm
=========================================================

.. automodule:: gensim.summarization.pagerank_weighted
    :synopsis: Weighted PageRank algorithm
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
