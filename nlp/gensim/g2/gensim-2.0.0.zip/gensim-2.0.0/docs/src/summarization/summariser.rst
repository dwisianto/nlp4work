:mod:`summarization.summarizer` -- TextRank Summariser
=========================================================

.. automodule:: gensim.summarization.summarizer
    :synopsis: TextRank Summariser
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
