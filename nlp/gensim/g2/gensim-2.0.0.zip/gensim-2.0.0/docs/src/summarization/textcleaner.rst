:mod:`summarization.textcleaner` -- Summarization pre-processing
=========================================================

.. automodule:: gensim.summarization.textcleaner
    :synopsis: Summarization pre-processing
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
b
