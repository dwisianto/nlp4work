:mod:`summarization.commons` -- Common graph functions
=========================================================

.. automodule:: gensim.summarization.commons
    :synopsis: Common graph functions
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
