:mod:`models.wrappers.fasttext` -- FastText Word Embeddings
===========================================================

.. automodule:: gensim.models.wrappers.fasttext
    :synopsis: FastText Embeddings
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
