:mod:`models.wrappers.wordrank` -- Word Embeddings from WordRank 
================================================================================================

.. automodule:: gensim.models.wrappers.wordrank
    :synopsis: Wordrank Embeddings
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
