:mod:`models.normmodel` -- Normalization model
===============================================

.. automodule:: gensim.models.normmodel
    :synopsis: Normalization model
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
