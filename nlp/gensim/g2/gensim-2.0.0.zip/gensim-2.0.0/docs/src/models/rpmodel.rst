:mod:`models.rpmodel` -- Random Projections
======================================================

.. automodule:: gensim.models.rpmodel
    :synopsis: Random Projections
    :members:
    :inherited-members:

