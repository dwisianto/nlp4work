:mod:`models.keyedvectors` -- Store and query word vectors
==========================================================

.. automodule:: gensim.models.keyedvectors
    :synopsis: Store and query word vectors
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
