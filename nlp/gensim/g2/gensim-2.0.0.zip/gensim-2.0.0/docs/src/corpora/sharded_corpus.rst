:mod:`corpora.sharded_corpus` -- Corpus stored in separate files
==========================================================

.. automodule:: gensim.corpora.sharded_corpus
    :synopsis: Numpy arrays on disk for iterative processing 
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
