:mod:`topic_coherence.aggregation` -- Aggregation module
========================================================

.. automodule:: gensim.topic_coherence.aggregation
    :synopsis: Aggregation module
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
