:mod:`topic_coherence.direct_confirmation_measure` -- Direct confirmation measure module
========================================================================================

.. automodule:: gensim.topic_coherence.direct_confirmation_measure
    :synopsis: Direct confirmation measure module
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
