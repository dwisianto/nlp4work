:mod:`parsing.porter` -- Porter Stemming Algorithm
=========================================================

.. automodule:: gensim.parsing.porter
    :synopsis: Porter Stemming Algorithm
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
