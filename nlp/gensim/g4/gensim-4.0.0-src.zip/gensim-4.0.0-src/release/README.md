Scripts to help when making new releases.

For more info, see [our Wiki page](https://github.com/RaRe-Technologies/gensim/wiki/Developer-page#make-a-new-release-for-maintainers).
