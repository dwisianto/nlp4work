Tutorials: Learning Oriented Lessons
------------------------------------

Learning-oriented lessons that introduce a particular gensim feature, e.g. a model (Word2Vec, FastText) or technique (similarity queries or text summarization).
