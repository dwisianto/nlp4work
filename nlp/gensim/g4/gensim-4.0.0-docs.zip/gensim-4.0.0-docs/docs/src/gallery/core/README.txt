Core Tutorials: New Users Start Here!
-------------------------------------

If you're new to gensim, we recommend going through all core tutorials in order.
Understanding this functionality is vital for using gensim effectively.
