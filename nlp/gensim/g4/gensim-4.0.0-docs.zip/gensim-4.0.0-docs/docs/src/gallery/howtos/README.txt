How-to Guides: Solve a Problem
------------------------------

These **goal-oriented guides** demonstrate how to **solve a specific problem** using gensim.
