:mod:`scripts.glove2word2vec` -- Convert glove format to word2vec
=================================================================

.. automodule:: gensim.scripts.glove2word2vec
    :synopsis: Convert glove format to word2vec
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
