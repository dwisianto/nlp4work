:mod:`scripts.make_wiki_online` -- Convert articles from a Wikipedia dump
=========================================================================

.. automodule:: gensim.scripts.make_wiki_online
    :synopsis: Convert articles from a Wikipedia dump
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
