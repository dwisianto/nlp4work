:mod:`scripts.word2vec_standalone` -- Train word2vec on text file CORPUS
========================================================================

.. automodule:: gensim.scripts.word2vec_standalone
    :synopsis: Train word2vec on text file CORPUS
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
