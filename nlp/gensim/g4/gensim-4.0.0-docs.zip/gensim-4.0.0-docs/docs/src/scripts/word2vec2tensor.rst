:mod:`scripts.word2vec2tensor` -- Convert the word2vec format to Tensorflow 2D tensor
=====================================================================================

.. automodule:: gensim.scripts.word2vec2tensor
    :synopsis: Convert the word2vec format to Tensorflow 2D tensor
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
