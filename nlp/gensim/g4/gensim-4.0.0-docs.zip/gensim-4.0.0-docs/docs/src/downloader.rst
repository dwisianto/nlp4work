:mod:`downloader` -- Downloader API for gensim
==============================================

.. automodule:: gensim.downloader
    :synopsis: Downloader API for gensim
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
