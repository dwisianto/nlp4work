:mod:`topic_coherence.text_analysis` -- Analyzing the texts of a corpus to accumulate statistical information about word occurrences
====================================================================================================================================

.. automodule:: gensim.topic_coherence.text_analysis
    :synopsis: Analyzing the texts of a corpus to accumulate statistical information about word occurrences
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
    :special-members: __getitem__
