:mod:`test.utils` -- Internal testing functions
===============================================

.. automodule:: gensim.test.utils
    :synopsis: Common utils used in testing Gensim internally
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
