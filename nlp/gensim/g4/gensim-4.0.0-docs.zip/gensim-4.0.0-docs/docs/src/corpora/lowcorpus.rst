:mod:`corpora.lowcorpus` -- Corpus in GibbsLda++ format
=======================================================

.. automodule:: gensim.corpora.lowcorpus
    :synopsis: Corpus in GibbsLda++ format
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
