:mod:`corpora.ucicorpus` -- Corpus in UCI format
================================================

.. automodule:: gensim.corpora.ucicorpus
    :synopsis: Corpus in UCI format
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
