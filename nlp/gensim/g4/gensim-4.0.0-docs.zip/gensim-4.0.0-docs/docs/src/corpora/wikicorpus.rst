:mod:`corpora.wikicorpus` -- Corpus from a Wikipedia dump
==========================================================

.. automodule:: gensim.corpora.wikicorpus
    :synopsis: Corpus from a Wikipedia dump
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
