:mod:`corpora.csvcorpus` -- Corpus in CSV format
==========================================================

.. automodule:: gensim.corpora.csvcorpus
    :synopsis: Corpus in CSV format
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
