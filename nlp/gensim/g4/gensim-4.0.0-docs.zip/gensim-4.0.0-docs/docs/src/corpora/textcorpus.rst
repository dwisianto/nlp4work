:mod:`corpora.textcorpus` -- Tools for building corpora with dictionaries
=========================================================================

.. automodule:: gensim.corpora.textcorpus
    :synopsis: Tools for building corpora with dictionaries
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
