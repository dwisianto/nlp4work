:mod:`similarities.nmslib` -- Approximate Vector Search using NMSLIB
====================================================================

.. automodule:: gensim.similarities.nmslib
    :synopsis: Fast Approximate Nearest Neighbor Similarity with the NMSLIB package
    :members:
    :inherited-members:

