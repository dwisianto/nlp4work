:mod:`models.word2vec_inner` -- Cython routines for training Word2Vec models
============================================================================

.. automodule:: gensim.models.word2vec_inner
    :synopsis: Optimized Cython routines for training Word2Vec models
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
