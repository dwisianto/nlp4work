:mod:`models._fasttext_bin` -- Facebook's fastText I/O
======================================================

.. automodule:: gensim.models._fasttext_bin
    :synopsis: I/O routines for Facebook's fastText format
    :members:
    :inherited-members:
    :special-members: __getitem__
    :undoc-members:
    :show-inheritance:
