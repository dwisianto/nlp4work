:mod:`models.doc2vec_inner` -- Cython routines for training Doc2Vec models
==========================================================================

.. automodule:: gensim.models.doc2vec_inner
    :synopsis: Optimized Cython routines for training Doc2Vec models
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
