:mod:`models.fasttext` -- FastText model
========================================

.. automodule:: gensim.models.fasttext
    :synopsis: FastText model
    :members:
    :inherited-members:
    :special-members: __getitem__
    :undoc-members:
    :show-inheritance:
