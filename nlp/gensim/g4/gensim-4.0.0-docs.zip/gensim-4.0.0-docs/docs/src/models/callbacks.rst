:mod:`models.callbacks` -- Callbacks for track and viz LDA train process
========================================================================

.. automodule:: gensim.models.callbacks
    :synopsis: Callbacks for track and viz LDA train process
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
