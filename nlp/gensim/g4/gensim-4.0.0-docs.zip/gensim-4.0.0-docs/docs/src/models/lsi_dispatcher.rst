:mod:`models.lsi_dispatcher` -- Dispatcher for distributed LSI
===============================================================

.. automodule:: gensim.models.lsi_dispatcher
    :synopsis: Dispatcher for distributed LSI
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
