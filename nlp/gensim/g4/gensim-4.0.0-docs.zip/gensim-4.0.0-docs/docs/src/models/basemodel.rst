:mod:`models.basemodel` -- Core TM interface
============================================

.. automodule:: gensim.models.basemodel
    :synopsis: Core TM interface
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
