:mod:`models.word2vec` -- Word2vec embeddings
=============================================

.. automodule:: gensim.models.word2vec
    :synopsis: Word2vec embeddings
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
