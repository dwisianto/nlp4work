#
# Push local branches to upstream (github.com).
#
# Run this after you've verified the results of merge.sh.
#
git push --tags upstream master
git push upstream develop
