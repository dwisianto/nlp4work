tox -e compile,docs
cd docs/src
make upload
