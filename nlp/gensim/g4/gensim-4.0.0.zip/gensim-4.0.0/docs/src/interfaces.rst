:mod:`interfaces` -- Core gensim interfaces
============================================

.. automodule:: gensim.interfaces
    :synopsis: Core gensim interfaces
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
