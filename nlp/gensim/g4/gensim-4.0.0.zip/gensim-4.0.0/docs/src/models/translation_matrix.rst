:mod:`models.translation_matrix` -- Translation Matrix model
=============================================================

.. automodule:: gensim.models.translation_matrix
    :synopsis: Translation Matrix
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
