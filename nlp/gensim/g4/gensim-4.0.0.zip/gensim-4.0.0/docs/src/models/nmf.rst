:mod:`models.nmf` -- Non-Negative Matrix factorization
======================================================

.. automodule:: gensim.models.nmf
    :synopsis: Non-Negative Matrix Factorization
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
