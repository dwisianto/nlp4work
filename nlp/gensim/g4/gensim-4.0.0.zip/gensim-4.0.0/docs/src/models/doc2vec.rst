:mod:`models.doc2vec` -- Doc2vec paragraph embeddings
=====================================================

.. automodule:: gensim.models.doc2vec
    :synopsis: Doc2vec paragraph embeddings
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
