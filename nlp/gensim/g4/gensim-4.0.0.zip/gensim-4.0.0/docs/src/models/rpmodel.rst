:mod:`models.rpmodel` -- Random Projections
======================================================

.. automodule:: gensim.models.rpmodel
    :synopsis: Random Projections
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
    :special-members: __getitem__
