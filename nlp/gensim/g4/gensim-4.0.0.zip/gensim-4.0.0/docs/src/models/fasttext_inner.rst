:mod:`models.fasttext_inner` -- Cython routines for training FastText models
============================================================================

.. automodule:: gensim.models.fasttext_inner
    :synopsis: Optimized Cython routines for training FastText models
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
