:mod:`models.atmodel` -- Author-topic models
======================================================

.. automodule:: gensim.models.atmodel
    :synopsis: Author-topic model
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
