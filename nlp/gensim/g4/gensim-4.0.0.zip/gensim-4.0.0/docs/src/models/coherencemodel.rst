:mod:`models.coherencemodel` -- Topic coherence pipeline
========================================================

.. automodule:: gensim.models.coherencemodel
    :synopsis: Topic coherence pipeline
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
