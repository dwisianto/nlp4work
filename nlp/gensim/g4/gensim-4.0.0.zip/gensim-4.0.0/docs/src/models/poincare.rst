:mod:`models.poincare` -- Train and use Poincare embeddings
=============================================================

.. automodule:: gensim.models.poincare
    :synopsis: Train and use Poincare embeddings
    :members:
    :inherited-members:
    :special-members: __iter__, __getitem__, __contains__
    :undoc-members:
    :show-inheritance:
