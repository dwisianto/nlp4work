.. toctree::
   :hidden:
   :maxdepth: 1

   intro
   auto_examples/index
   apiref
   support
   people
