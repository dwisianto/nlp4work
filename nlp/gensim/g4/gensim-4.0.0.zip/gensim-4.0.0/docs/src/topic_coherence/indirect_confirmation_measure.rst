:mod:`topic_coherence.indirect_confirmation_measure` -- Indirect confirmation measure module
============================================================================================

.. automodule:: gensim.topic_coherence.indirect_confirmation_measure
    :synopsis: Indirect confirmation measure module
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
