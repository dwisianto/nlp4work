:mod:`similarities.annoy` -- Approximate Vector Search using Annoy
==================================================================

.. automodule:: gensim.similarities.annoy
    :synopsis: Fast Approximate Nearest Neighbor Similarity with the Annoy package
    :members:
    :inherited-members:

