:mod:`similarities.termsim` -- Term similarity queries
========================================================================

.. automodule:: gensim.similarities.termsim
    :synopsis: Term similarity queries
    :members:
    :inherited-members:

