:mod:`corpora.malletcorpus` -- Corpus in Mallet format
======================================================

.. automodule:: gensim.corpora.malletcorpus
    :synopsis: Corpus in Mallet format.
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
