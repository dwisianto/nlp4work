:mod:`scripts.make_wikicorpus` -- Convert articles from a Wikipedia dump to vectors. 
====================================================================================

.. automodule:: gensim.scripts.make_wikicorpus
    :synopsis: Convert articles from a Wikipedia dump to vectors. 
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
