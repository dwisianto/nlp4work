:mod:`scripts.package_info` -- Information about gensim package
===============================================================

.. automodule:: gensim.scripts.package_info
    :synopsis: Information about gensim package.
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
