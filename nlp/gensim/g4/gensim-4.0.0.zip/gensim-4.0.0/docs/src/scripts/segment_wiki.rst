:mod:`scripts.segment_wiki` -- Convert wikipedia dump to json-line format
=========================================================================

.. automodule:: gensim.scripts.segment_wiki
    :synopsis: Convert wikipedia dump to json-line format.
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
