:mod:`summarization.keywords` -- Keywords for TextRank summarization algorithm
==============================================================================

.. automodule:: gensim.summarization.keywords
    :synopsis: Keywords for TextRank summarization algorithm
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
