:mod:`summarization.syntactic_unit` -- Syntactic Unit class
===========================================================

.. automodule:: gensim.summarization.syntactic_unit
    :synopsis: Syntactic Unit class
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
