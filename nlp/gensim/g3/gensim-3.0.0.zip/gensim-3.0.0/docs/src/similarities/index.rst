:mod:`similarities.index` -- Fast Approximate Nearest Neighbor Similarity with Annoy package
============================================================================================

.. automodule:: gensim.similarities.index
    :synopsis: Fast Approximate Nearest Neighbor Similarity with Annoy package
    :members:
    :inherited-members:

