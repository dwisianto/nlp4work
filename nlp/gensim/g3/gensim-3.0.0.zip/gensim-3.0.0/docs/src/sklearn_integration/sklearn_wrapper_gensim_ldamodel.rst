:mod:`sklearn_integration.sklearn_wrapper_gensim_ldamodel` -- Scikit learn wrapper for Latent Dirichlet Allocation
=========================================================================================================================================

.. automodule:: gensim.sklearn_integration.sklearn_wrapper_gensim_ldamodel
    :synopsis: Scikit learn wrapper for LDA model
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
