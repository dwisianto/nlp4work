:mod:`models.wrappers.varembed` -- VarEmbed Word Embeddings
================================================================================================

.. automodule:: gensim.models.wrappers.varembed
    :synopsis: VarEmbed Word Embeddings
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
