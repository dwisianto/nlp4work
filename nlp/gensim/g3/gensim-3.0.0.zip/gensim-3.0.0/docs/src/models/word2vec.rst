:mod:`models.word2vec` -- Deep learning with word2vec
======================================================

.. automodule:: gensim.models.word2vec
    :synopsis: Deep learning with word2vec
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
