:mod:`models.tfidfmodel` -- TF-IDF model
======================================================

.. automodule:: gensim.models.tfidfmodel
    :synopsis: TF-IDF model
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
