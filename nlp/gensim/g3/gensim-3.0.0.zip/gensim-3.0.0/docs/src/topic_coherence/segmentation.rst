:mod:`topic_coherence.segmentation` -- Segmentation module
==========================================================

.. automodule:: gensim.topic_coherence.segmentation
    :synopsis: Segmentation module
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
