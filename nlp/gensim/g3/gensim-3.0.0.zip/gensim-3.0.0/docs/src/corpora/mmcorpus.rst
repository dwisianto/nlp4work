:mod:`corpora.mmcorpus` -- Corpus in Matrix Market format
==========================================================

.. automodule:: gensim.corpora.mmcorpus
    :synopsis: Corpus in Matrix Market format
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
