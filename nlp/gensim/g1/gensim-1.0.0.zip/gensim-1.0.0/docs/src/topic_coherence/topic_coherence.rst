:mod:`topic_coherence` -- Package for the topic coherence pipeline
==================================================================

.. automodule:: gensim.topic_coherence
    :synopsis: Package for the topic coherence pipeline
    :members:
    :inherited-members: