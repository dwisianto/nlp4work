:mod:`topic_coherence.probability_estimation` -- Probability estimation module
==============================================================================

.. automodule:: gensim.topic_coherence.probability_estimation
    :synopsis: Probability estimation module
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
