:mod:`summarization.graph` -- TextRank graph
=========================================================

.. automodule:: gensim.summarization.graph
    :synopsis: TextRank graph
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
