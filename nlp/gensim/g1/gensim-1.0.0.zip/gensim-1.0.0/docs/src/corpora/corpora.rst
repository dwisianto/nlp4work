:mod:`corpora` -- Package for corpora I/O
==========================================

.. automodule:: gensim.corpora
    :synopsis: Package for corpora I/O
    :members:
    :inherited-members:

