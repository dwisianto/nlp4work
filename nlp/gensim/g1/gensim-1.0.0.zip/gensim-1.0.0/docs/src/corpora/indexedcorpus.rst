:mod:`corpora.indexedcorpus` -- Random access to corpus documents
=================================================================

.. automodule:: gensim.corpora.indexedcorpus
    :synopsis: Random access to corpus documents
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:


.. autoclass:: IndexedCorpus
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance: