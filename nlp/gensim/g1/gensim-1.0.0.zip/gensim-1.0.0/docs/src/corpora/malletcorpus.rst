:mod:`corpora.malletcorpus` -- Corpus in Mallet format of List-Of-Words.
==========================================================

.. automodule:: gensim.corpora.malletcorpus
    :synopsis: Corpus in Mallet format of List-Of-Words.
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
