:mod:`sklearn_integration.sklearn_wrapper_gensim_ldamodel.SklearnWrapperLdaModel` -- Scikit learn wrapper for Latent Dirichlet Allocation
======================================================

.. automodule:: gensim.sklearn_integration.sklearn_wrapper_gensim_ldamodel.SklearnWrapperLdaModel
    :synopsis: Scikit learn wrapper for LDA model
    :members:
    :inherited-members:
    :undoc-members:
    :show-inheritance:
