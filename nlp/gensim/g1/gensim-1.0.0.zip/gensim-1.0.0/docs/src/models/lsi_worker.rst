:mod:`models.lsi_worker` -- Worker for distributed LSI
======================================================

.. automodule:: gensim.models.lsi_worker
    :synopsis: Worker for distributed LSI
    :members:
    :inherited-members:

